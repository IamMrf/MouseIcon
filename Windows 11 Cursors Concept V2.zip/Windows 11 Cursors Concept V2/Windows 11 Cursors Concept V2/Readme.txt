Hi! thank you for use my cursors.

To install them, you just have to go inside the folder of the cursor you want to install "dark" or "light", and you will find a file named install, just right click on it and in the menu press install. If you are in Windows 11, you will have to press first in "more options" to find the "install" option.

I hope you enjoy them!


AGREEMENT:

By Getting this Cursor Pack you're allowed to:

1. Use the cursor pack in your computer or whatever device is compatible.
2. Modify the cursor pack for personal use.
3. Publish your heavily modified version of the pack.
4. Share and distribute the pack of cursors without remuneration.

You're not allowed to:

1. Share and distribute the pack of cursors with remuneration.
2. Claim (and rename) my cursor pack as your own.
3. Use monetized URL shorteners to my site or files.


* https://bio.link/mosabbir_maruf